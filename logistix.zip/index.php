
<?php include 'header.php'; ?>
            <div id="main-content" class="site-main clearfix">
                <div id="content-wrap">
                    <div id="site-content" class="site-content clearfix">
                        <div id="inner-content" class="inner-content-wrap">
                            <div class="page-content">
                                <div id="rev_slider_01_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classic4export" data-source="gallery">
                                    <div id="rev_slider_01" class="rev_slider fullwidthabanner" data-version="5.4.1">
                                        <ul>
                                            <li data-transition="curtain-2" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="400" data-rotate="0" data-fstransition="curtain-2" data-fsmasterspeed="400" data-fsslotamount="0" data-saveperformance="off">

                                                <img src="assets/imgs/slider_bg3.jpg" alt="Ocean" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg">

                                                <div class="tp-caption Heading-big tp-resizeme text-white font-weight-600" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['228','185','142','117']" 
                                                    data-fontsize="['82','64','52','36']" 
                                                    data-lineheight="['86','72','62','42']" 
                                                    data-width="100%" 
                                                    data-height="['none','73','none','none']" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on"
                                                    data-frames='[{"from":"y:-50px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-n1px font-heading">NEED SUPPORT NOW ?</div>
                                                </div>

                                                <div class="tp-caption Heading-big tp-resizeme text-white font-weight-600" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['340','271','221','177']" 
                                                    data-fontsize="['82','64','52','36']" 
                                                    data-lineheight="['86','72','62','42']" 
                                                    data-width="100%" 
                                                    data-height="none" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-frames='[{"from":"y:-50px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-n1px font-heading">CONTACT ONLINE SUPPORT</div>
                                                </div>

                                                <div class="tp-caption 18 tp-resizeme text-white" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['472','377','315','244']" 
                                                    data-fontsize="['24','22','20','20']" 
                                                    data-lineheight="['28','28','28','36']" 
                                                    data-fontweight="['400','400','500','500']" 
                                                    data-letterspacing="['3','3','2','2']" 
                                                    data-width="100%" 
                                                    data-height="['29','29','29','none']" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-frames='[{"from":"x:200px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-3px font-heading">WE ARE HERE TO ANSWER ANY QUESTION YOU HAVE FOR US</div>
                                                </div>

                                                <div class="tp-caption" 
                                                    data-x="['center','left','center','center']" data-hoffset="['-133','258','0','0']" 
                                                    data-y="['middle','middle','middle','middle']" data-voffset="['172','127','91','80']" 
                                                    data-fontsize="['14','14','13','13']" 
                                                    data-lineheight="['24','24','26','26']" 
                                                    data-width="none" 
                                                    data-height="none" 
                                                    data-whitespace="nowrap" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-responsive="off" 
                                                    data-frames='[{"from":"x:-100px;opacity:0;","speed":500,"to":"o:1;","delay":800,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['left','left','left','left']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <a href="#" target="_blank" class="logistix-button big accent">LEARN MORE</a>
                                                </div>

                                                <div class="tp-caption" 
                                                    data-x="['center','left','center','center']" data-hoffset="['131','510','0','0']" 
                                                    data-y="['middle','middle','middle','middle']" data-voffset="['172','127','178','183']" 
                                                    data-fontsize="['14','13','13','13']" 
                                                    data-lineheight="['24','26','26','26']" 
                                                    data-width="none" 
                                                    data-height="none" 
                                                    data-whitespace="nowrap" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-responsive="off" 
                                                    data-frames='[{"from":"x:100px;opacity:0;","speed":500,"to":"o:1;","delay":800,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['inherit','inherit','inherit','inherit']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]"><a href="#" target="_blank" class="logistix-button big white">WATCH VIDEO</a>
                                                </div>
                                            </li>

                                            <li data-transition="curtain-2" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="400" data-rotate="0" data-fstransition="curtain-2" data-fsmasterspeed="400" data-fsslotamount="0" data-saveperformance="off">

                                                <img src="assets/imgs/slider_bg2.jpg" alt="Ocean" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg">

                                                <div class="tp-caption Heading-big tp-resizeme text-white font-weight-600" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['228','185','142','117']" 
                                                    data-fontsize="['82','64','52','36']" 
                                                    data-lineheight="['86','72','62','42']" 
                                                    data-width="100%" 
                                                    data-height="['none','73','none','none']" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on"
                                                    data-frames='[{"from":"y:-50px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-n1px font-heading">WE PROVIDE FRESH &</div>
                                                </div>

                                                <div class="tp-caption Heading-big tp-resizeme text-white font-weight-600" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['340','271','221','177']" 
                                                    data-fontsize="['82','64','52','36']" 
                                                    data-lineheight="['86','72','62','42']" 
                                                    data-width="100%" 
                                                    data-height="none" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-frames='[{"from":"y:-50px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-n1px font-heading">SECURED DRONES LOGISTICS</div>
                                                </div>

                                                <div class="tp-caption 18 tp-resizeme text-white" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['472','377','315','244']" 
                                                    data-fontsize="['24','22','20','20']" 
                                                    data-lineheight="['28','28','28','36']" 
                                                    data-fontweight="['400','400','500','500']" 
                                                    data-letterspacing="['3','3','2','2']" 
                                                    data-width="100%" 
                                                    data-height="['29','29','29','none']" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-frames='[{"from":"x:200px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-3px font-heading">WHEN YOU NEED TO RECEIVE OR SEND PARCEL VERY FAST</div>
                                                </div>

                                                <div class="tp-caption" 
                                                    data-x="['center','left','center','center']" data-hoffset="['-133','258','0','0']" 
                                                    data-y="['middle','middle','middle','middle']" data-voffset="['172','127','91','80']" 
                                                    data-fontsize="['14','14','13','13']" 
                                                    data-lineheight="['24','24','26','26']" 
                                                    data-width="none" 
                                                    data-height="none" 
                                                    data-whitespace="nowrap" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-responsive="off" 
                                                    data-frames='[{"from":"x:-100px;opacity:0;","speed":500,"to":"o:1;","delay":800,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['left','left','left','left']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <a href="#" target="_blank" class="logistix-button big accent">LEARN MORE</a>
                                                </div>

                                                <div class="tp-caption" 
                                                    data-x="['center','left','center','center']" data-hoffset="['131','510','0','0']" 
                                                    data-y="['middle','middle','middle','middle']" data-voffset="['172','127','178','183']" 
                                                    data-fontsize="['14','13','13','13']" 
                                                    data-lineheight="['24','26','26','26']" 
                                                    data-width="none" 
                                                    data-height="none" 
                                                    data-whitespace="nowrap" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-responsive="off" 
                                                    data-frames='[{"from":"x:100px;opacity:0;","speed":500,"to":"o:1;","delay":800,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['inherit','inherit','inherit','inherit']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]"><a href="#" target="_blank" class="logistix-button big white">WATCH VIDEO</a>
                                                </div>
                                            </li>

                                            <li data-transition="curtain-2" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="400" data-rotate="0" data-fstransition="curtain-2" data-fsmasterspeed="400" data-fsslotamount="0" data-saveperformance="off">

                                                <img src="assets/imgs/slider_bg1.jpg" alt="Ocean" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" class="rev-slidebg">

                                                <div class="tp-caption Heading-big tp-resizeme text-white font-weight-600" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['228','185','142','117']" 
                                                    data-fontsize="['82','64','52','36']" 
                                                    data-lineheight="['86','72','62','42']" 
                                                    data-width="100%" 
                                                    data-height="['none','73','none','none']" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on"
                                                    data-frames='[{"from":"y:-50px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-n1px font-heading">DISCOVER LOGISTIX NOW</div>
                                                </div>

                                                <div class="tp-caption Heading-big tp-resizeme text-white font-weight-600" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['340','271','221','177']" 
                                                    data-fontsize="['82','64','52','36']" 
                                                    data-lineheight="['86','72','62','42']" 
                                                    data-width="100%" 
                                                    data-height="none" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-frames='[{"from":"y:-50px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-n1px font-heading">HUGE TRANSPORT HOLDING</div>
                                                </div>

                                                <div class="tp-caption 18 tp-resizeme text-white" 
                                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                                    data-y="['top','top','top','top']" data-voffset="['472','377','315','244']" 
                                                    data-fontsize="['24','22','20','20']" 
                                                    data-lineheight="['28','28','28','36']" 
                                                    data-fontweight="['400','400','500','500']" 
                                                    data-letterspacing="['3','3','2','2']" 
                                                    data-width="100%" 
                                                    data-height="['29','29','29','none']" 
                                                    data-whitespace="normal" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-frames='[{"from":"x:200px;opacity:0;","speed":500,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['center','center','center','center']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <div class="letter-spacing-3px font-heading">WE ARE THE BEST COMPANY FOR CARGO & TRANSPORTATION</div>
                                                </div>

                                                <div class="tp-caption" 
                                                    data-x="['center','left','center','center']" data-hoffset="['-133','258','0','0']" 
                                                    data-y="['middle','middle','middle','middle']" data-voffset="['172','127','91','80']" 
                                                    data-fontsize="['14','14','13','13']" 
                                                    data-lineheight="['24','24','26','26']" 
                                                    data-width="none" 
                                                    data-height="none" 
                                                    data-whitespace="nowrap" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-responsive="off" 
                                                    data-frames='[{"from":"x:-100px;opacity:0;","speed":500,"to":"o:1;","delay":800,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['left','left','left','left']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]">
                                                    <a href="#" target="_blank" class="logistix-button big accent">LEARN MORE</a>
                                                </div>

                                                <div class="tp-caption" 
                                                    data-x="['center','left','center','center']" data-hoffset="['131','510','0','0']" 
                                                    data-y="['middle','middle','middle','middle']" data-voffset="['172','127','178','183']" 
                                                    data-fontsize="['14','13','13','13']" 
                                                    data-lineheight="['24','26','26','26']" 
                                                    data-width="none" 
                                                    data-height="none" 
                                                    data-whitespace="nowrap" 
                                                    data-type="text" 
                                                    data-responsive_offset="on" 
                                                    data-responsive="off" 
                                                    data-frames='[{"from":"x:100px;opacity:0;","speed":500,"to":"o:1;","delay":800,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"x:0;","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'
                                                    data-textalign="['inherit','inherit','inherit','inherit']" 
                                                    data-paddingtop="[0,0,0,0]" 
                                                    data-paddingright="[0,0,0,0]" 
                                                    data-paddingbottom="[0,0,0,0]" 
                                                    data-paddingleft="[0,0,0,0]"><a href="#" target="_blank" class="logistix-button big white">WATCH VIDEO</a>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div><!-- #rev_slider_01_wrapper -->

                                <div class="row-services">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="75" data-mobi="55" data-smobi="55"></div>
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-4">
                                                <div class="logistix-icon-box clearfix icon-left w80 accent-bg align-left rounded-100 has-width wow fadeIn" data-wow-delay="0.3s">
                                                    <div class="icon-wrap">
                                                        <i class="fa fa-bar-chart"></i>
                                                    </div>

                                                    <h3 class="heading style-1"><a target="_blank" href="#"><span>Flexible Pricing</span></a></h3>

                                                    <p class="desc"><span>We are very flexible in our pricing, we make sure at any step our clients benefit the most</span></p>
                                                </div><!-- .logistix-icon-box -->

                                                <div class="logistix-spacer clearfix" data-desktop="0" data-mobi="25" data-smobi="25"></div>
                                            </div><!-- .col-md-4 -->

                                            <div class="col-md-4">
                                                <div class="logistix-icon-box clearfix icon-left w80 accent-bg align-left rounded-100 has-width wow fadeIn" data-wow-delay="0.4s">
                                                    <div class="icon-wrap">
                                                        <i class="fa fa-leaf"></i>
                                                    </div>

                                                    <h3 class="heading style-1"><a target="_blank" href="#"><span>Creative Solutions</span></a></h3>

                                                    <p class="desc"><span>Our solutions is simply the best for both a small and big business. it works for everybody</span></p>
                                                </div><!-- .logistix-icon-box -->

                                                <div class="logistix-spacer clearfix" data-desktop="0" data-mobi="25" data-smobi="25"></div>
                                            </div><!-- .col-md-4 -->

                                            <div class="col-md-4">
                                                <div class="logistix-icon-box clearfix icon-left w80 accent-bg align-left rounded-100 has-width wow fadeIn" data-wow-delay="0.5s">
                                                    <div class="icon-wrap">
                                                        <i class="fa fa-umbrella"></i>
                                                    </div>

                                                    <h3 class="heading style-1"><a target="_blank" href="#"><span>Best Support</span></a></h3>

                                                    <p class="desc"><span>We give our clients the support whenever they are in need, we make sure the are confortable to work with us.</span></p>
                                                </div><!-- .logistix-icon-box -->
                                            </div><!-- .col-md-4 -->

                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="75" data-mobi="55" data-smobi="55"></div>
                                            </div><!-- .col-md-12 -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div><!-- .row-services -->

                                <div class="row-about-us">
                                    <div class="container-fluid bg-very-light">
                                        <div class="row equalize sm-equalize-auto">
                                            <div class="col-md-6 no-padding half-bg-1"></div>

                                            <div class="col-md-6">
                                                <div class="logistix-content-box clearfix" data-padding="" data-mobipadding="" data-margin="8.8% 15% 7.6% 22%" data-mobimargin="60px 0 50px 0">
                                                    <div class="inner">
                                                        <div class="logistix-accordions style-2">
                                                            <div class="accordion-item active no-icon">
                                                                <h3 class="accordion-heading"><span class="inner">Short Company Overview</span></h3>

                                                                <div class="accordion-content">
                                                                    <p><span>Back in 1971, recognising an opportunity to serve the northeast fishing community, Douglas and Helen Spence launched a road haulage company called D & H Spence. In direct competition with Charles Alexander and Partners, who were then one of the the biggest haulage companies in Scotland, their fleet of 25 vehicles transported fresh fish from Peterhead to Humberside and Tyneside on a daily basis. Moving from their base in Laurencekirk into Aberdeen in 1980 to purchase Tullos Cold Store the company was able to diversify into hauling both fresh and frozen goods all over the UK and Europe.

</span></p>
                                                                </div>
                                                            </div><!-- .accordion-item -->

                                                            <div class="accordion-item no-icon">
                                                                <h3 class="accordion-heading"><span class="inner">Transportation Mission & Vision</span></h3>

                                                                <div class="accordion-content">
                                                                    <p><span>1984 saw a severe downturn in the fish industry, which led the company to diversify again into the oil industry. The cold store side of the business was sold in 1988 to concentrate on the oil and paper industries throughout the UK and Europe.
In 1990 Douglas & Helen Spence’s son Mark joined the firm and MGS Transport was established. The following year, the first Stepframe trailer was purchased to specialise in heavy haulage and abnormal loads for the oil industry. With the addition of the first Lowloader in 1996, the company has become one of the leaders in the heavy haulage and abnormal load business.</span></p>
                                                                </div>
                                                            </div><!-- .accordion-item -->

                                                    
                                                        </div><!-- .logistix-accordions -->
                                                    </div>
                                                </div><!-- .logistix-content-box -->
                                            </div><!-- .col-md-6 -->
                                        </div><!-- .row -->
                                    </div><!-- .container-fluid -->
                                </div><!-- .row-about-us -->

                            

                                <div class="row-countto parallax">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="80" data-mobi="60" data-smobi="60"></div>
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-3">
                                                <div class="logistix-content-box clearfix " data-padding="22px 20px 27px 20px" data-mobipadding="25px 20px 30px 20px" data-margin="" data-mobimargin="">
                                                    <div class="inner light-accent">
                                                        <div class="logistix-counter clearfix no-icon text-center">
                                                            <div class="number-wrap font-heading">
                                                                <span class="prefix"></span><span class="number accent" data-speed="5000" data-from="0" data-to="53">53</span><span class="suffix">M</span>
                                                            </div>

                                                            <h6 class="heading">Packages Shipped</h6>
                                                        </div>
                                                    </div>
                                                </div><!-- .logistix-content-box -->

                                                <div class="logistix-spacer clearfix" data-desktop="0" data-mobi="35" data-smobi="35"></div>
                                            </div><!-- .col-md-3 -->

                                            <div class="col-md-3">
                                                <div class="logistix-content-box clearfix " data-padding="22px 20px 27px 20px" data-mobipadding="25px 20px 30px 20px" data-margin="" data-mobimargin="">
                                                    <div class="inner light-accent">
                                                        <div class="logistix-counter clearfix no-icon text-center">
                                                            <div class="number-wrap font-heading">
                                                                <span class="prefix"></span><span class="number accent" data-speed="5000" data-from="0" data-to="130">130</span><span class="suffix">%</span>
                                                            </div>

                                                            <h6 class="heading">Creative Materials</h6>
                                                        </div>
                                                    </div>
                                                </div><!-- .logistix-content-box -->

                                                <div class="logistix-spacer clearfix" data-desktop="0" data-mobi="35" data-smobi="35"></div>
                                            </div><!-- .col-md-3 -->

                                            <div class="col-md-3">
                                                <div class="logistix-content-box clearfix " data-padding="22px 20px 27px 20px" data-mobipadding="25px 20px 30px 20px" data-margin="" data-mobimargin="">
                                                    <div class="inner light-accent">
                                                        <div class="logistix-counter clearfix no-icon text-center">
                                                            <div class="number-wrap font-heading">
                                                                <span class="prefix"></span><span class="number accent" data-speed="5000" data-from="0" data-to="15">15</span><span class="suffix">K</span>
                                                            </div>

                                                            <h6 class="heading">Experienced Masters</h6>
                                                        </div>
                                                    </div>
                                                </div><!-- .logistix-content-box -->

                                                <div class="logistix-spacer clearfix" data-desktop="0" data-mobi="35" data-smobi="35"></div>
                                            </div><!-- .col-md-3 -->

                                            <div class="col-md-3">
                                                <div class="logistix-content-box clearfix " data-padding="22px 20px 27px 20px" data-mobipadding="25px 20px 30px 20px" data-margin="" data-mobimargin="">
                                                    <div class="inner light-accent">
                                                        <div class="logistix-counter clearfix no-icon text-center">
                                                            <div class="number-wrap font-heading">
                                                                <span class="prefix"></span><span class="number accent" data-speed="5000" data-from="0" data-to="34">34</span><span class="suffix">$</span>
                                                            </div>

                                                            <h6 class="heading">Professional Awards</h6>
                                                        </div>
                                                    </div>
                                                </div><!-- .logistix-content-box -->
                                            </div><!-- .col-md-3 -->

                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="80" data-mobi="60" data-smobi="60"></div>
                                            </div><!-- .col-md-12 -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div><!-- .row-countto -->

                                <div class="row-recent-rojects">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="93" data-mobi="73" data-smobi="73"></div>

                                                <div class="logistix-single-heading clearfix text-center style-1">
                                                    <h2 class="heading">Recent Projects</h2>
                                                </div><!-- .logistix-single-heading -->

                                                <div class="logistix-divider has-icon width-50">
                                                    <div class="divider-icon">
                                                        <span class="divider-icon-before divider-center divider-double-dotted"></span>
                                                        <span class="icon-wrap"><span class="logistixs-flash accent"></span></span>
                                                        <span class="divider-icon-after divider-center divider-double-dotted"></span>
                                                    </div>
                                                </div><!-- .logistix-divider -->

                                                <div class="clearfix"></div>

                                                <div class="logistix-single-heading clearfix text-center style-2">
                                                    <h4 class="heading">Duis aute irure dolor in reprehenderit in voluptate velit esse</h4>
                                                </div><!-- .logistix-single-heading -->

                                                <div class="logistix-spacer clearfix" data-desktop="60" data-mobi="40" data-smobi="40"></div>
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-12 no-padding">
                                                <div class="logistix-project grid-full arrow-dark arrow-center bullet-circle offsetcenter offset-v0 has-bullets grid-full bullet35" data-loop="true" data-auto="true" data-column="3" data-column2="2" data-column3="1" data-gap="20">
                                                    <div class="logistix-container">
                                                        <div class="owl-carousel owl-theme owl-loaded owl-drag">
                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery1-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery1-590x440.jpg" data-title="Huge Plane"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Huge Plane"><h2 data-title="Huge Vehicle">Huge Plane</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->

                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery2-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery2-590x440.jpg" data-title="Cargo Truck"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Cargo Truck"><h2 data-title="Cargo Truck">Cargo Truck</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->

                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery3-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery3-590x440.jpg" data-title="Super Airplane"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Super Airplane"><h2 data-title="Super Airplane">Super Airplane</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->

                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery4-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery4-590x440.jpg" data-title="Mega Truck"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Mega Truck"><h2 data-title="Mega Truck">Mega Truck</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->

                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery5-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery5-590x440.jpg" data-title="Huge Plane"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Huge Plane"><h2 data-title="Huge Plane">Huge Plane</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->

                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery6-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery6-590x440.jpg" data-title="Truck Monster"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Truck Monster"><h2 data-title="Truck Monster">Truck Monster</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->

                                                            <div class="project-box style-2">
                                                                <div class="inner">
                                                                    <div class="project-wrap">
                                                                        <div class="project-image">
                                                                            <img width="590" height="440" src="assets/imgs/project/gallery7-590x440.jpg" alt="Image">
                                                                        </div>

                                                                        <div class="project-text">
                                                                            <div class="icon">
                                                                                <a class="link" href="#"><i class="coreicon-plus2"></i></a>
                                                                                <a class="zoom-popup" href="assets/imgs/project/gallery7-590x440.jpg" data-title="Cargo Truck"><i class="coreicon-magnifier3"></i></a>
                                                                            </div>
                                                                        </div>

                                                                        <a href="#" title="Cargo Truck"><h2 data-title="Cargo Truck">Cargo Truck</h2></a>
                                                                    </div>
                                                                </div>
                                                            </div><!-- .project-box -->
                                                        </div>
                                                    </div><!-- .logistix-container -->
                                                </div><!-- .logistix-project -->
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="100" data-mobi="80" data-smobi="80"></div>
                                            </div><!-- .col-md-12 -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div><!-- .recent-roject -->


                                <div class="row-why-choose-us">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="95" data-mobi="75" data-smobi="75"></div>
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-6">
                                                <div class="logistix-single-heading clearfix style-1">
                                                    <h2 class="heading">Why Choose Us ?</h2>
                                                </div>

                                                <div class="logistix-spacer clearfix" data-desktop="20" data-mobi="10" data-smobi="10"></div>

                                                <div class="text-wrap">
                                                    <p class="margin-bottom-0">Selecting a freight forwarding firm is an important decision for your company. Your company must be able to depend on its freight forwarder in order to uphold and continue its own engagement of quality and services towards your own customers, while considering service level, flexibility and cost. At Logistix, you receive so much more than just a standard logistics company. We know that true success is about customer satisfaction, so we’ve made it our goal to continue to develop the services that will save our customers time and money. By being a medium size company, Logistix can elaborate a tailor-made solution to all its customers. At Logistix, we listen, adapt, and provide efficient results for all your needs.</p>
                                                </div><!-- .text-wrap -->

                                                <div class="logistix-spacer clearfix" data-desktop="0" data-mobi="40" data-smobi="40"></div>
                                            </div><!-- .col-md-6 -->

                                            <div class="col-md-6">
                                                <div class="logistix-progress style-1 clearfix height-10px">
                                                    <h3 class="title">MARKETING</h3>
                                                    <div class="perc-wrap">
                                                        <div class="perc"><span>95%</span></div>
                                                    </div>
                                                    <div class="progress-bg" data-percent="95%" data-inviewport="yes">
                                                        <div class="progress-animate"></div>
                                                    </div>
                                                </div><!-- .logistix-progress -->

                                                <div class="logistix-spacer clearfix" data-desktop="40" data-mobi="30" data-smobi="30"></div>

                                                <div class="logistix-progress style-1 clearfix height-10px">
                                                    <h3 class="title">LOGISTICS</h3>
                                                    <div class="perc-wrap">
                                                        <div class="perc"><span>70%</span></div>
                                                    </div>
                                                    <div class="progress-bg" data-percent="70%" data-inviewport="yes">
                                                        <div class="progress-animate"></div>
                                                    </div>
                                                </div><!-- .logistix-progress -->

                                                <div class="logistix-spacer clearfix" data-desktop="40" data-mobi="30" data-smobi="30"></div>

                                                <div class="logistix-progress style-1 clearfix height-10px">
                                                    <h3 class="title">DEVELOPMENT</h3>
                                                    <div class="perc-wrap">
                                                        <div class="perc"><span>85%</span></div>
                                                    </div>
                                                    <div class="progress-bg" data-percent="85%" data-inviewport="yes">
                                                        <div class="progress-animate"></div>
                                                    </div>
                                                </div><!-- .logistix-progress -->
                                            </div><!-- .col-md-6 -->

                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="95" data-mobi="80" data-smobi="80"></div>
                                            </div><!-- .col-md-12 -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div><!-- .row-why-choose-us -->

                                <div class="row-promotion-video bg-very-light">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="100" data-mobi="75" data-smobi="75"></div>
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-6">
                                                <div class="logistix-icon-box clearfix icon-left w80 accent-bg align-left rounded-100 has-width wow fadeIn" data-wow-delay="0.2s">
                                                    <div class="icon-wrap">
                                                        <i class="fa fa-bar-chart"></i>
                                                    </div>

                                                    <h3 class="heading style-1"><a target="_blank" href="#"><span>Flexible Pricing</span></a></h3>

                                                    <p class="desc"><span>We are very flexible in our pricing, we make sure at any step our clients benefit the most. Our prices may change along the way, but it won't affect our clients. we make sure they benefit</span></p>
                                                </div><!-- .logistix-icon-box -->
                                                
                                                <div class="logistix-spacer clearfix" data-desktop="50" data-mobi="25" data-smobi="25"></div>

                                                <div class="logistix-icon-box clearfix icon-left w80 accent-bg align-left rounded-100 has-width wow fadeIn" data-wow-delay="0.3s">
                                                    <div class="icon-wrap">
                                                        <i class="fa fa-leaf"></i>
                                                    </div>

                                                    <h3 class="heading style-1"><a target="_blank" href="#"><span>Creative Solutions</span></a></h3>

                                                    <p class="desc"><span>Our solutions is simply the best for both a small and big business. it works for everybody. We Make sure our solution is the best, ranging from fast delivery and warehousing space</span></p>
                                                </div><!-- .logistix-icon-box -->

                                                <div class="logistix-spacer clearfix" data-desktop="50" data-mobi="25" data-smobi="25"></div>

                                                <div class="logistix-icon-box clearfix icon-left w80 accent-bg align-left rounded-100 has-width wow fadeIn" data-wow-delay="0.4s">
                                                    <div class="icon-wrap">
                                                        <i class="fa fa-umbrella"></i>
                                                    </div>

                                                    <h3 class="heading style-1"><a target="_blank" href="#"><span>Best Support</span></a></h3>

                                                    <p class="desc"><span>We give our clients the support whenever they are in need, we make sure the are confortable to work with us. At time we face deficulties during transit. in all this cases we notify our clients</span></p>
                                                </div><!-- .logistix-icon-box -->
                                            </div><!-- .col-md-6 -->

                                            <div class="col-md-6">
                                                <div class="logistix-content-box clearfix" data-padding="0 0 0 15px" data-mobipadding="52px 0 0 0">
                                                    <div class="inner">
                                                        <div class="logistix-img-advanced clearfix text-center">
                                                            <div class="thumb">
                                                                <img width="565" height="393" src="assets/imgs/img2-1.jpg" alt="Image">
                                                                <a class="icon-wrap popup-video" href="https://www.youtube.com/watch?v=mIcr_p-kzKs"></a>
                                                            </div>

                                                            <div class="img-caption">TRANSPORT PROCESS VIDEO</div>
                                                        </div><!-- .logistix-img-advanced -->
                                                    </div>
                                                </div><!-- .logistix-content-box -->
                                            </div><!-- .col-md-6 -->

                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="95" data-mobi="80" data-smobi="80"></div>
                                            </div><!-- .col-md-12 -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div><!-- .row-promotion-video -->

                                <div class="row-testimonials">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="93" data-mobi="73" data-smobi="73"></div>

                                                <div class="logistix-single-heading clearfix text-center style-1">
                                                    <h2 class="heading">Testimonials</h2>
                                                </div><!-- .logistix-single-heading -->

                                                <div class="logistix-divider has-icon width-50">
                                                    <div class="divider-icon">
                                                        <span class="divider-icon-before divider-center divider-double-dotted"></span>
                                                        <span class="icon-wrap"><span class="logistixs-bank-support accent"></span></span>
                                                        <span class="divider-icon-after divider-center divider-double-dotted"></span>
                                                    </div>
                                                </div><!-- .logistix-divider -->

                                                <div class="clearfix"></div>

                                                <div class="logistix-single-heading clearfix text-center style-2">
                                                    <h4 class="heading"></h4>
                                                </div><!-- .logistix-single-heading -->

                                                <div class="logistix-spacer clearfix" data-desktop="60" data-mobi="40" data-smobi="40"></div>
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-12">
                                                <div class="logistix-carousel-box arrow-dark arrow-center bullet-circle offset20 offset-v-70 has-bullets has-arrows bullet30" data-auto="true" data-loop="true" data-gap="25" data-column="3" data-column2="2" data-column3="1">
                                                    <div class="owl-carousel owl-theme owl-loaded owl-drag">
                                                        <div class="logistix-testimonials clearfix image-circle">
                                                            <div class="inner">
                                                                <blockquote class="text">Just a quick note to you to tell you how much we appreciate Ted’s help on two recent shipments to Chicago. We had a supplier who made a mess of their SID# filing, and this caused a good deal of concern with the local FDA office. As we got the situation resolved, the case was transferred to a very challenging FDA officer in the local compliance division. Ted helped us navigate the challenges we faced and got our goods cleared in a week’s time –pretty incredible given the situation. We just wanted to make you aware of all the help that Ted gave us on this – we really appreciate your help in supporting our business!”</blockquote>
                                                            </div>

                                                            <div class="image-wrap">
                                                                <div class="thumb"><img width="70" height="70" src="assets/imgs/testimonials/testimonial1.png" alt="Image"></div>
                                                            </div>

                                                            <div class="name-wrap">
                                                                <div class="name-pos">
                                                                    <h6 class="name"><span>Tom Battat</span></h6>
                                                                  
                                                                </div>
                                                            </div>
                                                        </div><!-- .logistix-testimonials -->

                                                        <div class="logistix-testimonials clearfix image-circle">
                                                            <div class="inner">
                                                                <blockquote class="text">I have been doing business with American International Cargo Service for a couple of years. We send an antifreeze type solution to China for various construction projects. To say that shipment dates, money transfers and confusion to quantities requires multiple changes before the project is actually shipped is an understatement.American International Cargo Service takes every one of my changes with a positive attitude and a professional manner. Their flexibility and expertise in arranging my freight to get to its Chinese destination in a predictable and timely manner does what every manager hopes for. They make me look good.</blockquote>
                                                            </div>

                                                            <div class="image-wrap">
                                                                <div class="thumb"><img width="70" height="70" src="assets/imgs/testimonials/testimonial2.png" alt="Image"></div>
                                                            </div>

                                                            <div class="name-wrap">
                                                                <div class="name-pos">
                                                                    <h6 class="name"><span>Houghton Chemical Corporation</span></h6>
                                                                  
                                                                </div>
                                                            </div>
                                                        </div><!-- .logistix-testimonials -->

                                                        <div class="logistix-testimonials clearfix image-circle">
                                                            <div class="inner">
                                                                <blockquote class="text">I have been working with American Shipping for over 20 years. I have always found their rates competitive, but it is their service that adds the extra value for me. Their staff is knowledgeable and courteous and their response time is prompt. I know I can trust their expertise when inquiring on anything from customs regulations to import logistics in a new port….. Using them for our freight forwarding, customs brokerage and inland trucking allows us to maintain a smooth flow from the time the goods leave the factory until the time they reach our customer's door and I can access real time tracking along the way”</blockquote>
                                                            </div>

                                                            <div class="image-wrap">
                                                                <div class="thumb"><img width="70" height="70" src="assets/imgs/testimonials/testimonial3.png" alt="Image"></div>
                                                            </div>

                                                            <div class="name-wrap">
                                                                <div class="name-pos">
                                                                    <h6 class="name"><span>Justin Marquis</span></h6>
                                                                
                                                                </div>
                                                            </div>
                                                        </div><!-- .logistix-testimonials -->

                                                        <div class="logistix-testimonials clearfix image-circle">
                                                            <div class="inner">
                                                                <blockquote class="text">Hi Roy/Chris (and all others who helped us get these hot containers delivered into Linn at The American Companies), I just wanted to extend our appreciation for your dedicated attention in getting all these containers delivered! Very much appreciated! I was on a call this morning with my boss from London (as you can imagine, everyone has their eyes on these shipments!). Peter mentioned to me to be sure to let you know how impressed he is by your performance in keeping us up to date. He mentioned that the communications you are providing are being transmitted “to the top” (which means the big big guy ). So please know that we at Elsevier (from bottom -me- to top - Adrian in Amsterdam- are very much appreciative of your efforts on keeping us informed!”</blockquote>
                                                            </div>

                                                            <div class="image-wrap">
                                                                <div class="thumb"><img width="70" height="70" src="assets/imgs/testimonials/testimonial1.png" alt="Image"></div>
                                                            </div>

                                                            <div class="name-wrap">
                                                                <div class="name-pos">
                                                                    <h6 class="name"><span>Vicki Schepers
Elsevier</span></h6>
                                                                
                                                                </div>
                                                            </div>
                                                        </div><!-- .logistix-testimonials -->
                                                    </div><!-- .owl-carousel -->
                                                </div><!-- .logistix-carousel-box -->
                                            </div><!-- .col-md-12 -->

                                            <div class="col-md-12">
                                                <div class="logistix-spacer clearfix" data-desktop="80" data-mobi="60" data-smobi="60"></div>
                                            </div><!-- .col-md-12 -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div><!-- .row-testimonials -->
                            </div><!-- .page-content -->
                        </div><!-- #inner-content -->
                    </div><!-- #site-content -->
                </div><!-- #content-wrap -->
            </div><!-- #main-content -->

            <?php include 'footer.php'; ?>